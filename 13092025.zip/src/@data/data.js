export const publicationFrequencies = ["Monthly", "Quarterly", "Biannual", "Annual","4 Issue Per Year"];
export const languages = ["English", "Hindi", "Tamil", "French", "Arabic"];
export const formatofpublication = ["Online","Print"]
