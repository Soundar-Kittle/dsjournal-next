import React from 'react';
import { AssignEditorialRolesForm } from '@/components/Dashboard/EditorialBoard/Create/AssignEditorialRolesForm';

const page = () => {
  return (
    <div>Assign Roles page

      <AssignEditorialRolesForm/>

    </div>
  )
}

export default page