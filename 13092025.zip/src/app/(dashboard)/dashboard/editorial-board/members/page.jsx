import React from 'react';
import EditorialMembersForm from '@/components/Dashboard/EditorialBoard/Create/EditorialMembersForm';

const page = () => {
  return (
    <div>Memebers page

   
    <EditorialMembersForm/>
    </div>
  )
}

export default page