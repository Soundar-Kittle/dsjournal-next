
import React from 'react'
import { EditorialTitlesForm } from '@/components/Dashboard/EditorialBoard/Create/EditorialTitlesForm'
const page = () => {
  return (
    <div>Titles page

        <EditorialTitlesForm/>
    </div>
  )
}

export default page