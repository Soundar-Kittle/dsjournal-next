import React from 'react'

const page = () => {
  return (
    <div>Citation Page</div>
  )
}

export default page