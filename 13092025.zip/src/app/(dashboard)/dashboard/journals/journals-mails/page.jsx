import React from 'react';
import Addform from '@/components/Dashboard/Journals/journalsmaildetails/Addform';

const page = () => {
  return (
    <>
        <Addform/>
    </>
  )
}

export default page