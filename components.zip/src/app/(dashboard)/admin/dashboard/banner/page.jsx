import ManageBanner from "@/components/Dashboard/Banner/ManageBanner";

const page = () => {
  return (
    <div>
      <ManageBanner />
    </div>
  );
};

export default page;
