import ManageBanner from "@/components/Dashboard/Meta/ManageMeta";

const page = () => {
  return (
    <div>
      <ManageBanner />
    </div>
  );
};

export default page;
