import VerifyOtp from "@/components/Auth/VerifyOtp";

const page = () => {
  return (
    <div>
      <VerifyOtp />
    </div>
  );
};

export default page;
