import ForgotPassword from "@/components/Auth/ForgotPassword";

const page = () => {
  return (
    <div>
      <ForgotPassword />
    </div>
  );
};

export default page;
