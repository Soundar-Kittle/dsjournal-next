import Login from "@/components/Auth/Login";

const page = () => {
  return <Login role="author" />;
};

export default page;
