import Register from "@/components/Auth/Register";

const page = () => {
  return <Register role="author" />;
};

export default page;
