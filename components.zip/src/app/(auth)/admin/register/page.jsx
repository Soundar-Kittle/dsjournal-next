import Register from "@/components/Auth/Register";

const page = () => {
  return <Register role="admin" />;
};

export default page;
