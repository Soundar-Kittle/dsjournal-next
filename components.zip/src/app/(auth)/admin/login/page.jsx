import Login from "@/components/Auth/Login";

const page = () => {
  return <Login role="admin" />;
};

export default page;
