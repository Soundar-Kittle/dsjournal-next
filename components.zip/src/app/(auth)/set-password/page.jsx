import SetPassword from "@/components/Auth/SetPassword";

const page = () => {
  return (
    <div>
      <SetPassword />
    </div>
  );
};

export default page;
